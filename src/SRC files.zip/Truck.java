public interface Truck {
    int getAxles();
    double getWeight();
    void displayData();
}
